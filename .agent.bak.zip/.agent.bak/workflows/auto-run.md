---
description: 自动执行规则 - 减少人工确认
---

// turbo-all

# 自动执行规则

此工作流启用自动执行模式，减少人工确认步骤。

## 自动执行范围
- 安全的读取操作（view_file, list_dir, grep_search 等）
- npm/yarn 安装和运行命令
- git status, log, diff 等查询命令
- 创建目录和复制文件
- 开发服务器启动

## 仍需确认的操作
- 删除文件或目录
- git push, reset, rebase 等修改操作
- 系统级更改
- 任何可能造成数据丢失的操作
