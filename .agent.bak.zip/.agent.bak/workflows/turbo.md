---
description: 全局 Turbo 模式 - 自动运行所有命令，无需用户确认
---

// turbo-all

# 全局自动确认设置

此工作流启用全局 turbo 模式，所有命令将自动运行，无需用户逐一确认。

## 适用范围
- 所有 `npm` 命令（install, run dev, build 等）
- 所有 `git` 命令
- 所有 `mkdir`, `cp`, `mv` 文件操作命令
- 所有开发服务器启动命令
- 所有测试命令

## 注意事项
- 危险操作（如 `rm -rf`、`git push --force`）仍会提示确认
- 如需恢复手动确认，请删除此文件
